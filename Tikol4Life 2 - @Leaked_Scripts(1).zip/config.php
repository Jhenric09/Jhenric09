<?php
//Script Author: ᴛɪᴋᴏʟ4ʟɪғᴇ https://t.me/Tikol4Life

//-----------------------------------------------------------------------------------------//
//Website Basic Informations
$site_name = '【★𝘽𝙂★】';
$site_icon = 'assets/img/BG.jpg';
$owner = '【★𝘽𝙂★】';

$forceHttps = false; //Highly Recommended if SSL Certificate/HTTPS is available
$forceAuth = false; //Require Users to input AuthPass
$AuthPass = 'Tikol4Life'; 


//-----------------------------------------------------------------------------------------//
//Telegram Bot Informations
$bot_name = "OppaTikolero Bot"; //change this to any bot name you want.
$bot_token = "xxxxxxxxxx:xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx"; //change this to your own bot Token.
$token_url = 'https://api.telegram.org/bot'.$bot_token;


//-----------------------------------------------------------------------------------------//
//API Informations
$testMode = false; //Show cURL Responses

//$api_name[] = '𝐒𝐓𝐑𝐈𝐏𝐄 𝐆𝟏 ×× [need SK]';
//$api_file[] = 'Stripe_1_New.php';

//$api_name[] = '𝐒𝐓𝐑𝐈𝐏𝐄 𝐆𝟐 ×× [need SK]';
//$api_file[] = 'Stripe_2_New.php';

$api_name[] = '𝐒𝐓𝐑𝐈𝐏𝐄 𝐆𝟑 ×× [need SK]';
$api_file[] = 'Stripe_3_New.php';

//[] = '𝐒𝐓𝐑𝐈𝐏𝐄 𝐆𝟒 ×× [need SK]';
//$api_file[] = 'Stripe_4_New.php';


//-----------------------------------------------------------------------------------------//
//BugBin Exclusion Setup
$bug_bin[] = "489504";
$bug_bin[] = "41528505";
$bug_bin[] = "51546200";
$bug_bin[] = "559558";
$bug_bin[] = "543816";
$bug_bin[] = "529750";
$bug_bin[] = "512319";
$bug_bin[] = "519479";
$bug_bin[] = "554642";
$bug_bin[] = "429304";


//-----------------------------------------------------------------------------------------//
//Redirect Links
$red_link [] = "https://www.youtube.com/embed/kOHB85vDuow?start=1&autoplay=1";	//Twice - Fancy
$red_link [] = "https://www.youtube.com/embed/mH0_XpSHkZo?start=1&autoplay=1";	//Twice - More & More
$red_link [] = "https://www.youtube.com/embed/mAKsZ26SabQ?start=1&autoplay=1";	//Twice - Yes or Yes
$red_link [] = "https://www.youtube.com/embed/i0p1bmr0EmE?start=1&autoplay=1";	//Twice - What is Love?
$red_link [] = "https://www.youtube.com/embed/rRzxEiBLQCA?start=1&autoplay=1";	//Twice - Heart Shaker
$red_link [] = "https://www.youtube.com/embed/c7rCyll5AeY?start=1&autoplay=1";	//Twice - Cheer Up
$red_link [] = "https://www.youtube.com/embed/0rtV5esQT6I?start=1&autoplay=1";	//Twice - Like OOH-AHH
$red_link [] = "https://www.youtube.com/embed/J_CFBjAyPWE?start=1&autoplay=1";	//Red Velvet - Bad boy
$red_link [] = "https://www.youtube.com/embed/6uJf2IT2Zh8?start=1&autoplay=1";	//Red Velvet - Peek-A-Boo
$red_link [] = "https://www.youtube.com/embed/uR8Mrt1IpXg?start=1&autoplay=1";	//Red Velvet - Psycho
$red_link [] = "https://www.youtube.com/embed/WyiIGEHQP8o?start=1&autoplay=1";	//Red Velvet - Red Flavor
$red_link [] = "https://www.youtube.com/embed/ioNng23DkIM?start=1&autoplay=1";	//BlackPink - How You Like That
$red_link [] = "https://www.youtube.com/embed/2S24-y0Ij3Y?start=1&autoplay=1";	//BlackPink - Kill This Love
$red_link [] = "https://www.youtube.com/embed/IHNzOHi8sJs?start=1&autoplay=1";	//BlackPink - DDU-DU DDU-DU
$red_link [] = "https://www.youtube.com/embed/Amq-qlqbjYA?start=1&autoplay=1";	//BlackPink - As If It's Your Last
$red_link [] = "https://www.youtube.com/embed/fnPn6At3v28?start=1&autoplay=1";	//BlackPink - Sour Candy
$red_link [] = "https://www.youtube.com/embed/vRXZj0DzXIA?start=1&autoplay=1";	//BlackPink - Ice Cream
$red_link [] = "https://www.youtube.com/embed/fE2h3lGlOsk?start=1&autoplay=1";	//Itzy - Wannabe
$red_link [] = "https://www.youtube.com/embed/zndvqTc4P9I?start=1&autoplay=1";	//Itzy - Icy
$red_link [] = "https://www.youtube.com/embed/pNfTK39k55U?start=1&autoplay=1";	//Itzy - Dalla Dalla
$red_link [] = "https://www.youtube.com/embed/wTowEKjDGkU?start=1&autoplay=1";	//Itzy - Not Shy
$red_link [] = "https://www.youtube.com/embed/TgOu00Mf3kI?start=1&autoplay=1";	//IU - _ eight
$red_link [] = "https://www.youtube.com/embed/D1PvIWdJ8xo?start=1&autoplay=1";	//IU - _ Blueming
$red_link [] = "https://www.youtube.com/embed/nM0xDI5R50E?start=1&autoplay=1";	//IU - BBIBBI
$red_link [] = "https://www.youtube.com/embed/d9IxdwEFk1c?start=1&autoplay=1";	//IU - Palette
$red_link [] = "https://www.youtube.com/embed/tDukIfFzX18?start=1&autoplay=1";	//Hwa Sa - _ Maria
$red_link [] = "https://www.youtube.com/embed/lBYyAQ99ZFI?start=1&autoplay=1";	//SOMI - What You Waiting For
$red_link [] = "https://www.youtube.com/embed/gdZLi9oWNZg?start=1&autoplay=1";	//BTS - Dynamite
$red_link [] = "https://www.youtube.com/embed/XsX3ATc3FbA?start=1&autoplay=1";	//BTS - Boy With Luv
$red_link [] = "https://www.youtube.com/embed/MBdVXkSdhwU?start=1&autoplay=1";	//BTS - DNA


//-----------------------------------------------------------------------------------------//
?>